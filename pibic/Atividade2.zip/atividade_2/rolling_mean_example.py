import pandas as pd
from matplotlib.pylab import rcParams
import matplotlib.pyplot as plt

rcParams['figure.figsize'] = 15, 6

def do_rolling_mean(time_series):
    rolmean = pd.rolling_mean(time_series, window=12)

    df=pd.DataFrame({'x': range(1,len(time_series)+1), 'Rolling Mean':rolmean, 'Time Series': time_series
                    })


    plt.plot( 'x', 'Rolling Mean', data=df,  markersize=12, color='blue', linewidth=3,linestyle='-')
    plt.plot( 'x', 'Time Series', data=df,  color='black', linewidth=2,linestyle='--')
    plt.legend(loc='best')

    plt.title('Rolling Mean')

    plt.show(block=False)

time_series = pd.read_csv('./coloradoRiver.txt')
do_rolling_mean(time_series['data'].values)